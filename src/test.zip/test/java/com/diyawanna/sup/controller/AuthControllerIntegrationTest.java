package com.diyawanna.sup.controller;

import com.diyawanna.sup.dto.LoginRequest;
import com.diyawanna.sup.dto.RegisterRequest;
import com.diyawanna.sup.entity.User;
import com.diyawanna.sup.repository.UserRepository;
import com.diyawanna.sup.util.JwtUtil;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;

//import org.springframework.boot.test.mock.mockito.MockBean;   //// The @MockBean annotation has been deprecated in Spring Boot 3.x.
import org.mockito.Mock;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for AuthController
 *
 * @author Diyawanna Team
 * @version 1.0.0
 */
@SpringBootTest
@AutoConfigureWebMvc
@ActiveProfiles("test")

@DisplayName("AuthController Integration Tests")

class AuthControllerIntegrationTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    @MockitoBean
    private UserRepository userRepository;

    @MockitoBean
    private PasswordEncoder passwordEncoder;

    @MockitoBean
    private JwtUtil jwtUtil;

    private MockMvc mockMvc;
    private ObjectMapper objectMapper;
    private User testUser;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        objectMapper = new ObjectMapper();

        testUser = new User();
        testUser.setId("user123");
        testUser.setName("John Doe");
        testUser.setUsername("johndoe");
        testUser.setEmail("john@example.com");
        testUser.setPassword("hashedPassword");
        testUser.setAge(25);
        testUser.setActive(true);
        testUser.setCreatedAt(LocalDateTime.now());
        testUser.setUpdatedAt(LocalDateTime.now());
    }

    @Test
    void login_WithValidCredentials_ShouldReturnToken() throws Exception {
        // Given
        LoginRequest loginRequest = new LoginRequest("johndoe", "password123");

        when(userRepository.findByUsername("johndoe")).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches("password123", "hashedPassword")).thenReturn(true);
        when(jwtUtil.generateToken("johndoe")).thenReturn("jwt-token");

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.token").value("jwt-token"))
                .andExpect(jsonPath("$.username").value("johndoe"));

        verify(userRepository).findByUsername("johndoe");
        verify(passwordEncoder).matches("password123", "hashedPassword");
        verify(jwtUtil).generateToken("johndoe");
    }

    @Test
    void login_WithInvalidCredentials_ShouldReturnError() throws Exception {
        // Given
        LoginRequest loginRequest = new LoginRequest("johndoe", "wrongpassword");

        when(userRepository.findByUsername("johndoe")).thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches("wrongpassword", "hashedPassword")).thenReturn(false);

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").exists());

        verify(userRepository).findByUsername("johndoe");
        verify(passwordEncoder).matches("wrongpassword", "hashedPassword");
        verify(jwtUtil, never()).generateToken(anyString());
    }

    @Test
    void login_WithNonExistentUser_ShouldReturnError() throws Exception {
        // Given
        LoginRequest loginRequest = new LoginRequest("nonexistent", "password123");

        when(userRepository.findByUsername("nonexistent")).thenReturn(Optional.empty());

        // When & Then
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").exists());

        verify(userRepository).findByUsername("nonexistent");
        verify(passwordEncoder, never()).matches(anyString(), anyString());
        verify(jwtUtil, never()).generateToken(anyString());
    }

    @Test
    void register_WithValidData_ShouldCreateUser() throws Exception {
        // Given
        RegisterRequest registerRequest = new RegisterRequest();
        registerRequest.setName("Jane Doe");
        registerRequest.setUsername("janedoe");
        registerRequest.setEmail("jane@example.com");
        registerRequest.setPassword("password123");
        registerRequest.setAge(24);
        registerRequest.setUniversity("University of Colombo");

        User newUser = new User();
        newUser.setId("user456");
        newUser.setName("Jane Doe");
        newUser.setUsername("janedoe");
        newUser.setEmail("jane@example.com");
        newUser.setPassword("hashedPassword");
        newUser.setAge(24);
        newUser.setUniversity("University of Colombo");
        newUser.setActive(true);
        newUser.setCreatedAt(LocalDateTime.now());
        newUser.setUpdatedAt(LocalDateTime.now());

        when(userRepository.existsByUsername("janedoe")).thenReturn(false);
        when(userRepository.existsByEmail("jane@example.com")).thenReturn(false);
        when(passwordEncoder.encode("password123")).thenReturn("hashedPassword");
        when(userRepository.save(any(User.class))).thenReturn(newUser);

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(registerRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").exists())
                .andExpect(jsonPath("$.user.username").value("janedoe"))
                .andExpect(jsonPath("$.user.password").doesNotExist()); // Password should not be returned

        verify(userRepository).existsByUsername("janedoe");
        verify(userRepository).existsByEmail("jane@example.com");
        verify(passwordEncoder).encode("password123");
        verify(userRepository).save(any(User.class));
    }

    @Test
    void register_WithExistingUsername_ShouldReturnError() throws Exception {
        // Given
        RegisterRequest registerRequest = new RegisterRequest();
        registerRequest.setName("Jane Doe");
        registerRequest.setUsername("johndoe"); // Existing username
        registerRequest.setEmail("jane@example.com");
        registerRequest.setPassword("password123");

        when(userRepository.existsByUsername("johndoe")).thenReturn(true);

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(registerRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").exists());

        verify(userRepository).existsByUsername("johndoe");
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void register_WithInvalidData_ShouldReturnValidationError() throws Exception {
        // Given
        RegisterRequest registerRequest = new RegisterRequest();
        registerRequest.setName(""); // Invalid: empty name
        registerRequest.setUsername(""); // Invalid: empty username
        registerRequest.setEmail("invalid-email"); // Invalid: bad email format
        registerRequest.setPassword("123"); // Invalid: too short

        // When & Then
        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(registerRequest)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Validation failed"));

        verify(userRepository, never()).existsByUsername(anyString());
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void validateToken_WithValidToken_ShouldReturnValid() throws Exception {
        // Given
        String validToken = "valid-jwt-token";

        when(jwtUtil.validateToken(validToken)).thenReturn(true);
        when(jwtUtil.extractUsername(validToken)).thenReturn("johndoe");

        // When & Then
        mockMvc.perform(post("/api/auth/validate")
                .header("Authorization", "Bearer " + validToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.valid").value(true))
                .andExpect(jsonPath("$.username").value("johndoe"));

        verify(jwtUtil).validateToken(validToken);
        verify(jwtUtil).extractUsername(validToken);
    }

    @Test
    void validateToken_WithInvalidToken_ShouldReturnInvalid() throws Exception {
        // Given
        String invalidToken = "invalid-jwt-token";

        when(jwtUtil.validateToken(invalidToken)).thenReturn(false);

        // When & Then
        mockMvc.perform(post("/api/auth/validate")
                .header("Authorization", "Bearer " + invalidToken))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.valid").value(false));

        verify(jwtUtil).validateToken(invalidToken);
        verify(jwtUtil, never()).extractUsername(anyString());
    }

    @Test
    void validateToken_WithoutToken_ShouldReturnError() throws Exception {
        // When & Then
        mockMvc.perform(post("/api/auth/validate"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").exists());

        verify(jwtUtil, never()).validateToken(anyString());
    }

    @Test
    void refreshToken_WithValidToken_ShouldReturnNewToken() throws Exception {
        // Given
        String oldToken = "old-jwt-token";
        String newToken = "new-jwt-token";

        when(jwtUtil.validateToken(oldToken)).thenReturn(true);
        when(jwtUtil.extractUsername(oldToken)).thenReturn("johndoe");
        when(jwtUtil.generateToken("johndoe")).thenReturn(newToken);

        // When & Then
        mockMvc.perform(post("/api/auth/refresh")
                .header("Authorization", "Bearer " + oldToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.token").value(newToken))
                .andExpect(jsonPath("$.username").value("johndoe"));

        verify(jwtUtil).validateToken(oldToken);
        verify(jwtUtil).extractUsername(oldToken);
        verify(jwtUtil).generateToken("johndoe");
    }


    //    // Constants for better maintainability
//    private static final String LOGIN_ENDPOINT = "/api/auth/login";
//    private static final String REGISTER_ENDPOINT = "/api/auth/register";
//    private static final String VALIDATE_ENDPOINT = "/api/auth/validate";
//    private static final String REFRESH_ENDPOINT = "/api/auth/refresh";
//
//    private static final String TEST_USERNAME = "johndoe";
//    private static final String TEST_EMAIL = "john@example.com";
//    private static final String TEST_PASSWORD = "password123";
//    private static final String HASHED_PASSWORD = "hashedPassword";
//    private static final String JWT_TOKEN = "jwt-token";
//
//    @BeforeEach
//    void setUp() {
//        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
//        objectMapper = new ObjectMapper();
//
//        testUser = createTestUser();
//    }
//
//    private User createTestUser() {
//        User user = new User();
//        user.setId("user123");
//        user.setName("John Doe");
//        user.setUsername(TEST_USERNAME);
//        user.setEmail(TEST_EMAIL);
//        user.setPassword(HASHED_PASSWORD);
//        user.setAge(25);
//        user.setActive(true);
//        user.setCreatedAt(LocalDateTime.now());
//        user.setUpdatedAt(LocalDateTime.now());
//        return user;
//    }
//
//    @Nested
//    @DisplayName("Login Tests")
//    class LoginTests {
//
//        @Test
//        @DisplayName("Should return token when credentials are valid")
//        void login_WithValidCredentials_ShouldReturnToken() throws Exception {
//            // Given
//            LoginRequest loginRequest = new LoginRequest(TEST_USERNAME, TEST_PASSWORD);
//
//            when(userRepository.findByUsername(TEST_USERNAME)).thenReturn(Optional.of(testUser));
//            when(passwordEncoder.matches(TEST_PASSWORD, HASHED_PASSWORD)).thenReturn(true);
//            when(jwtUtil.generateToken(any())).thenReturn(JWT_TOKEN);
//
//            // When & Then
//            mockMvc.perform(post(LOGIN_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(loginRequest)))
//                    .andExpect(status().isOk())
//                    .andExpect(jsonPath("$.success").value(true))
//                    .andExpect(jsonPath("$.token").value(JWT_TOKEN))
//                    .andExpect(jsonPath("$.username").value(TEST_USERNAME));
//
//            verify(userRepository).findByUsername(TEST_USERNAME);
//            verify(passwordEncoder).matches(TEST_PASSWORD, HASHED_PASSWORD);
//            verify(jwtUtil).generateToken(any());
//        }
//
//        @Test
//        @DisplayName("Should return error when password is incorrect")
//        void login_WithInvalidCredentials_ShouldReturnError() throws Exception {
//            // Given
//            String wrongPassword = "wrongpassword";
//            LoginRequest loginRequest = new LoginRequest(TEST_USERNAME, wrongPassword);
//
//            when(userRepository.findByUsername(TEST_USERNAME)).thenReturn(Optional.of(testUser));
//            when(passwordEncoder.matches(wrongPassword, HASHED_PASSWORD)).thenReturn(false);
//
//            // When & Then
//            mockMvc.perform(post(LOGIN_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(loginRequest)))
//                    .andExpect(status().isUnauthorized())
//                    .andExpect(jsonPath("$.success").value(false))
//                    .andExpect(jsonPath("$.error").exists());
//
//            verify(userRepository).findByUsername(TEST_USERNAME);
//            verify(passwordEncoder).matches(wrongPassword, HASHED_PASSWORD);
//            verify(jwtUtil, never()).generateToken(any());
//        }
//
//        @Test
//        @DisplayName("Should return error when user does not exist")
//        void login_WithNonExistentUser_ShouldReturnError() throws Exception {
//            // Given
//            String nonExistentUser = "nonexistent";
//            LoginRequest loginRequest = new LoginRequest(nonExistentUser, TEST_PASSWORD);
//
//            when(userRepository.findByUsername(nonExistentUser)).thenReturn(Optional.empty());
//
//            // When & Then
//            mockMvc.perform(post(LOGIN_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(loginRequest)))
//                    .andExpect(status().isUnauthorized())
//                    .andExpect(jsonPath("$.success").value(false))
//                    .andExpect(jsonPath("$.error").exists());
//
//            verify(userRepository).findByUsername(nonExistentUser);
//            verify(passwordEncoder, never()).matches(anyString(), anyString());
//            verify(jwtUtil, never()).generateToken(any());
//        }
//
//        @Test
//        @DisplayName("Should return error when user account is inactive")
//        void login_WithInactiveUser_ShouldReturnError() throws Exception {
//            // Given
//            testUser.setActive(false);
//            LoginRequest loginRequest = new LoginRequest(TEST_USERNAME, TEST_PASSWORD);
//
//            when(userRepository.findByUsername(TEST_USERNAME)).thenReturn(Optional.of(testUser));
//
//            // When & Then
//            mockMvc.perform(post(LOGIN_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(loginRequest)))
//                    .andExpect(status().isUnauthorized())
//                    .andExpect(jsonPath("$.success").value(false))
//                    .andExpect(jsonPath("$.error").value("Account is inactive"));
//
//            verify(userRepository).findByUsername(TEST_USERNAME);
//            verify(passwordEncoder, never()).matches(anyString(), anyString());
//            verify(jwtUtil, never()).generateToken(any());
//        }
//
//        @Test
//        @DisplayName("Should return error with malformed JSON")
//        void login_WithMalformedJson_ShouldReturnError() throws Exception {
//            // When & Then
//            mockMvc.perform(post(LOGIN_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content("{ invalid json }"))
//                    .andExpect(status().isBadRequest());
//        }
//    }
//
//    @Nested
//    @DisplayName("Registration Tests")
//    class RegistrationTests {
//
//        @Test
//        @DisplayName("Should create user when registration data is valid")
//        void register_WithValidData_ShouldCreateUser() throws Exception {
//            // Given
//            RegisterRequest registerRequest = createValidRegisterRequest();
//            User newUser = createNewUser();
//
//            when(userRepository.existsByUsername("janedoe")).thenReturn(false);
//            when(userRepository.existsByEmail("jane@example.com")).thenReturn(false);
//            when(passwordEncoder.encode(TEST_PASSWORD)).thenReturn(HASHED_PASSWORD);
//            when(userRepository.save(any(User.class))).thenReturn(newUser);
//
//            // When & Then
//            mockMvc.perform(post(REGISTER_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(registerRequest)))
//                    .andExpect(status().isOk())
//                    .andExpect(jsonPath("$.success").value(true))
//                    .andExpect(jsonPath("$.message").exists())
//                    .andExpect(jsonPath("$.user.username").value("janedoe"))
//                    .andExpect(jsonPath("$.user.password").doesNotExist()); // Password should not be returned
//
//            verify(userRepository).existsByUsername("janedoe");
//            verify(userRepository).existsByEmail("jane@example.com");
//            verify(passwordEncoder).encode(TEST_PASSWORD);
//            verify(userRepository).save(any(User.class));
//        }
//
//        @Test
//        @DisplayName("Should return error when username already exists")
//        void register_WithExistingUsername_ShouldReturnError() throws Exception {
//            // Given
//            RegisterRequest registerRequest = createValidRegisterRequest();
//            registerRequest.setUsername(TEST_USERNAME); // Existing username
//
//            when(userRepository.existsByUsername(TEST_USERNAME)).thenReturn(true);
//
//            // When & Then
//            mockMvc.perform(post(REGISTER_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(registerRequest)))
//                    .andExpect(status().isBadRequest())
//                    .andExpect(jsonPath("$.success").value(false))
//                    .andExpect(jsonPath("$.error").value("Username already exists"));
//
//            verify(userRepository).existsByUsername(TEST_USERNAME);
//            verify(userRepository, never()).save(any(User.class));
//        }
//
//        @Test
//        @DisplayName("Should return error when email already exists")
//        void register_WithExistingEmail_ShouldReturnError() throws Exception {
//            // Given
//            RegisterRequest registerRequest = createValidRegisterRequest();
//            registerRequest.setEmail(TEST_EMAIL); // Existing email
//
//            when(userRepository.existsByUsername("janedoe")).thenReturn(false);
//            when(userRepository.existsByEmail(TEST_EMAIL)).thenReturn(true);
//
//            // When & Then
//            mockMvc.perform(post(REGISTER_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(registerRequest)))
//                    .andExpect(status().isBadRequest())
//                    .andExpect(jsonPath("$.success").value(false))
//                    .andExpect(jsonPath("$.error").value("Email already exists"));
//
//            verify(userRepository).existsByUsername("janedoe");
//            verify(userRepository).existsByEmail(TEST_EMAIL);
//            verify(userRepository, never()).save(any(User.class));
//        }
//
//        @Test
//        @DisplayName("Should return validation error with invalid data")
//        void register_WithInvalidData_ShouldReturnValidationError() throws Exception {
//            // Given
//            RegisterRequest registerRequest = new RegisterRequest();
//            registerRequest.setName(""); // Invalid: empty name
//            registerRequest.setUsername(""); // Invalid: empty username
//            registerRequest.setEmail("invalid-email"); // Invalid: bad email format
//            registerRequest.setPassword("123"); // Invalid: too short
//
//            // When & Then
//            mockMvc.perform(post(REGISTER_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(registerRequest)))
//                    .andExpect(status().isBadRequest())
//                    .andExpect(jsonPath("$.error").value("Validation failed"));
//
//            verify(userRepository, never()).existsByUsername(anyString());
//            verify(userRepository, never()).save(any(User.class));
//        }
//
//        private RegisterRequest createValidRegisterRequest() {
//            RegisterRequest request = new RegisterRequest();
//            request.setName("Jane Doe");
//            request.setUsername("janedoe");
//            request.setEmail("jane@example.com");
//            request.setPassword(TEST_PASSWORD);
//            request.setAge(24);
//            request.setUniversity("University of Colombo");
//            return request;
//        }
//
//        private User createNewUser() {
//            User user = new User();
//            user.setId("user456");
//            user.setName("Jane Doe");
//            user.setUsername("janedoe");
//            user.setEmail("jane@example.com");
//            user.setPassword(HASHED_PASSWORD);
//            user.setAge(24);
//            user.setUniversity("University of Colombo");
//            user.setActive(true);
//            user.setCreatedAt(LocalDateTime.now());
//            user.setUpdatedAt(LocalDateTime.now());
//            return user;
//        }
//    }
//
//    @Nested
//    @DisplayName("Token Validation Tests")
//    class TokenValidationTests {
//
//        @Test
//        @DisplayName("Should return valid when token is valid")
//        void validateToken_WithValidToken_ShouldReturnValid() throws Exception {
//            // Given
//            String validToken = "valid-jwt-token";
//
//            when(jwtUtil.validateToken(validToken)).thenReturn(true);
//            when(jwtUtil.extractUsername(validToken)).thenReturn(TEST_USERNAME);
//
//            // When & Then
//            mockMvc.perform(post(VALIDATE_ENDPOINT)
//                            .header("Authorization", "Bearer " + validToken))
//                    .andExpect(status().isOk())
//                    .andExpect(jsonPath("$.valid").value(true))
//                    .andExpect(jsonPath("$.username").value(TEST_USERNAME));
//
//            verify(jwtUtil).validateToken(validToken);
//            verify(jwtUtil).extractUsername(validToken);
//        }
//
//        @Test
//        @DisplayName("Should return invalid when token is invalid")
//        void validateToken_WithInvalidToken_ShouldReturnInvalid() throws Exception {
//            // Given
//            String invalidToken = "invalid-jwt-token";
//
//            when(jwtUtil.validateToken(invalidToken)).thenReturn(false);
//
//            // When & Then
//            mockMvc.perform(post(VALIDATE_ENDPOINT)
//                            .header("Authorization", "Bearer " + invalidToken))
//                    .andExpect(status().isUnauthorized())
//                    .andExpect(jsonPath("$.valid").value(false));
//
//            verify(jwtUtil).validateToken(invalidToken);
//            verify(jwtUtil, never()).extractUsername(anyString());
//        }
//
//        @Test
//        @DisplayName("Should return error when authorization header is missing")
//        void validateToken_WithoutToken_ShouldReturnError() throws Exception {
//            // When & Then
//            mockMvc.perform(post(VALIDATE_ENDPOINT))
//                    .andExpect(status().isBadRequest())
//                    .andExpect(jsonPath("$.error").exists());
//
//            verify(jwtUtil, never()).validateToken(anyString());
//        }
//
//        @Test
//        @DisplayName("Should return error when authorization header is malformed")
//        void validateToken_WithMalformedHeader_ShouldReturnError() throws Exception {
//            // When & Then
//            mockMvc.perform(post(VALIDATE_ENDPOINT)
//                            .header("Authorization", "InvalidFormat"))
//                    .andExpect(status().isBadRequest())
//                    .andExpect(jsonPath("$.error").exists());
//
//            verify(jwtUtil, never()).validateToken(anyString());
//        }
//
//        @Test
//        @DisplayName("Should return error when token is expired")
//        void validateToken_WithExpiredToken_ShouldReturnError() throws Exception {
//            // Given
//            String expiredToken = "expired-jwt-token";
//
//            when(jwtUtil.validateToken(expiredToken)).thenThrow(new RuntimeException("Token expired"));
//
//            // When & Then
//            mockMvc.perform(post(VALIDATE_ENDPOINT)
//                            .header("Authorization", "Bearer " + expiredToken))
//                    .andExpect(status().isUnauthorized())
//                    .andExpect(jsonPath("$.valid").value(false))
//                    .andExpect(jsonPath("$.error").value("Token expired"));
//
//            verify(jwtUtil).validateToken(expiredToken);
//        }
//    }
//
//    @Nested
//    @DisplayName("Token Refresh Tests")
//    class TokenRefreshTests {
//
//        @Test
//        @DisplayName("Should return new token when refresh token is valid")
//        void refreshToken_WithValidToken_ShouldReturnNewToken() throws Exception {
//            // Given
//            String oldToken = "old-jwt-token";
//            String newToken = "new-jwt-token";
//
//            when(jwtUtil.validateToken(oldToken)).thenReturn(true);
//            when(jwtUtil.extractUsername(oldToken)).thenReturn(TEST_USERNAME);
//            when(jwtUtil.generateToken(any())).thenReturn(newToken);
//
//            // When & Then
//            mockMvc.perform(post(REFRESH_ENDPOINT)
//                            .header("Authorization", "Bearer " + oldToken))
//                    .andExpect(status().isOk())
//                    .andExpect(jsonPath("$.success").value(true))
//                    .andExpect(jsonPath("$.token").value(newToken))
//                    .andExpect(jsonPath("$.username").value(TEST_USERNAME));
//
//            verify(jwtUtil).validateToken(oldToken);
//            verify(jwtUtil).extractUsername(oldToken);
//            verify(jwtUtil).generateToken(any());
//        }
//
//        @Test
//        @DisplayName("Should return error when refresh token is invalid")
//        void refreshToken_WithInvalidToken_ShouldReturnError() throws Exception {
//            // Given
//            String invalidToken = "invalid-jwt-token";
//
//            when(jwtUtil.validateToken(invalidToken)).thenReturn(false);
//
//            // When & Then
//            mockMvc.perform(post(REFRESH_ENDPOINT)
//                            .header("Authorization", "Bearer " + invalidToken))
//                    .andExpect(status().isUnauthorized())
//                    .andExpect(jsonPath("$.success").value(false))
//                    .andExpect(jsonPath("$.error").exists());
//
//            verify(jwtUtil).validateToken(invalidToken);
//            verify(jwtUtil, never()).extractUsername(anyString());
//            verify(jwtUtil, never()).generateToken(any());
//        }
//
//        @Test
//        @DisplayName("Should return error when authorization header is missing")
//        void refreshToken_WithoutToken_ShouldReturnError() throws Exception {
//            // When & Then
//            mockMvc.perform(post(REFRESH_ENDPOINT))
//                    .andExpect(status().isBadRequest())
//                    .andExpect(jsonPath("$.error").exists());
//
//            verify(jwtUtil, never()).validateToken(anyString());
//        }
//    }
//
//    @Nested
//    @DisplayName("Security Tests")
//    class SecurityTests {
//
//        @Test
//        @DisplayName("Should handle SQL injection attempts in username")
//        void login_WithSqlInjectionAttempt_ShouldHandleSafely() throws Exception {
//            // Given
//            String maliciousUsername = "admin'; DROP TABLE users; --";
//            LoginRequest loginRequest = new LoginRequest(maliciousUsername, TEST_PASSWORD);
//
//            when(userRepository.findByUsername(maliciousUsername)).thenReturn(Optional.empty());
//
//            // When & Then
//            mockMvc.perform(post(LOGIN_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(loginRequest)))
//                    .andExpect(status().isUnauthorized());
//
//            verify(userRepository).findByUsername(maliciousUsername);
//        }
//
//        @Test
//        @DisplayName("Should handle XSS attempts in registration data")
//        void register_WithXssAttempt_ShouldHandleSafely() throws Exception {
//            // Given
//            RegisterRequest registerRequest = new RegisterRequest();
//            registerRequest.setName("<script>alert('xss')</script>");
//            registerRequest.setUsername("testuser");
//            registerRequest.setEmail("test@example.com");
//            registerRequest.setPassword(TEST_PASSWORD);
//
//            when(userRepository.existsByUsername("testuser")).thenReturn(false);
//            when(userRepository.existsByEmail("test@example.com")).thenReturn(false);
//
//            // When & Then - Should sanitize or reject the malicious input
//            mockMvc.perform(post(REGISTER_ENDPOINT)
//                            .contentType(MediaType.APPLICATION_JSON)
//                            .content(objectMapper.writeValueAsString(registerRequest)))
//                    .andExpect(status().isBadRequest());
//        }
//    }
//
//    @Nested
//    @DisplayName("Rate Limiting Tests")
//    class RateLimitingTests {
//
//        @Test
//        @DisplayName("Should handle multiple failed login attempts")
//        void login_WithMultipleFailedAttempts_ShouldHandleRateLimit() throws Exception {
//            // Given
//            LoginRequest loginRequest = new LoginRequest(TEST_USERNAME, "wrongpassword");
//
//            when(userRepository.findByUsername(TEST_USERNAME)).thenReturn(Optional.of(testUser));
//            when(passwordEncoder.matches("wrongpassword", HASHED_PASSWORD)).thenReturn(false);
//
//            // When - Simulate multiple failed attempts
//            for (int i = 0; i < 3; i++) {
//                mockMvc.perform(post(LOGIN_ENDPOINT)
//                                .contentType(MediaType.APPLICATION_JSON)
//                                .content(objectMapper.writeValueAsString(loginRequest)))
//                        .andExpect(status().isUnauthorized());
//            }
//
//            // Then - Should handle rate limiting (implementation dependent)
//            // This test shows the structure but actual rate limiting logic
//            // would depend on your implementation
//        }
//    }
}

